import "./Footer.css";

const Footer = () => {
  return (
    <footer className="footer footer-bottom">
      <p className="footer-content">&copy; Whattpad. FER202.</p>
    </footer>
  );
};

export default Footer;
